<?php

define('baseurl','http://localhost/latihan_ukksalna2/public');