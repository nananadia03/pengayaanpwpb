<?php

define('BASEURL','http://localhost/ujikom_salna/public');
